# katoto_eggList
egg 请求接口

npm run dev 本地跑
npm start 服务器部署
npm stop  停止

上传代码的时候不带node_modules logs  run  等信息
//  iqiyi电视剧列表分页接口
http://192.168.50.47:7001/iqiyiTvlist?pageno=28&pagesize=10

年级接口
http://127.0.0.1:7001/educlassmsg?pageno=2&pagesize=3&className=Class6&xueke=Yuwen

教育资讯
http://127.0.0.1:7001/eduZixun?pageno=2&pagesize=2
iqiyiMovie 电影分页
http://127.0.0.1:7001/iqiyiMovie?pageno=3&pagesize=3
iqiyiTvlist 电视剧分页
http://127.0.0.1:7001/iqiyiTvlist?pageno=2&pagesize=2