# katoto_eggList
egg 请求接口

npm run dev 本地跑
npm start 服务器部署
npm stop  停止

//  iqiyi电视剧列表分页接口
http://192.168.50.47:7001/iqiyiTvlist?pageno=28&pagesize=10
